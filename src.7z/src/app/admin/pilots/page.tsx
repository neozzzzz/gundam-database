'use client'

import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'

export default function PilotsAdmin() {
  const router = useRouter()
  const supabase = createClientComponentClient()
  
  const [loading, setLoading] = useState(true)
  const [pilots, setPilots] = useState<any[]>([])
  const [factions, setFactions] = useState<any[]>([])
  const [factionsMap, setFactionsMap] = useState<Record<string, any>>({})
  const [msCounts, setMsCounts] = useState<Record<string, number>>({})
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedFaction, setSelectedFaction] = useState('')

  // 페이지네이션
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(20)
  const [totalCount, setTotalCount] = useState(0)

  useEffect(() => {
    checkAuth()
    loadFactions()
  }, [])

  useEffect(() => {
    if (Object.keys(factionsMap).length > 0 || factions.length === 0) {
      loadPilots()
    }
  }, [currentPage, searchTerm, selectedFaction, factionsMap])

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session || session.user.email !== process.env.NEXT_PUBLIC_ADMIN_EMAIL) {
      router.push('/admin/login')
    }
  }

  const loadFactions = async () => {
    const { data, error } = await supabase
      .from('factions')
      .select('*')
      .order('sort_order')
    
    if (error) {
      console.error('진영 로딩 오류:', error)
    }
    
    const factionsList = data || []
    setFactions(factionsList)
    
    // ID를 키로 하는 맵 생성
    const map: Record<string, any> = {}
    factionsList.forEach(f => {
      map[f.id] = f
    })
    setFactionsMap(map)
  }

  const loadPilots = async () => {
    try {
      setLoading(true)
      
      // 관계 조회 없이 pilots만 조회
      let query = supabase
        .from('pilots')
        .select('*', { count: 'exact' })
        .order('updated_at', { ascending: false })

      // 검색 필터
      if (searchTerm) {
        query = query.or(`name_ko.ilike.%${searchTerm}%,name_en.ilike.%${searchTerm}%`)
      }

      // 진영 필터 (affiliation_default_id 사용)
      if (selectedFaction) {
        const faction = factions.find(f => f.code === selectedFaction)
        if (faction) {
          query = query.eq('affiliation_default_id', faction.id)
        }
      }

      // 페이지네이션
      const from = (currentPage - 1) * itemsPerPage
      const to = from + itemsPerPage - 1
      query = query.range(from, to)

      const { data, error, count } = await query

      if (error) throw error
      setPilots(data || [])
      setTotalCount(count || 0)

      // 탑승 기체 수 조회
      if (data && data.length > 0) {
        const pilotIds = data.map((p: any) => p.id)
        const { data: msData } = await supabase
          .from('mobile_suits')
          .select('pilot_id')
          .in('pilot_id', pilotIds)

        // pilot_id별 count 계산
        const counts: Record<string, number> = {}
        if (msData) {
          msData.forEach((ms: any) => {
            if (ms.pilot_id) {
              counts[ms.pilot_id] = (counts[ms.pilot_id] || 0) + 1
            }
          })
        }
        setMsCounts(counts)
      }
    } catch (error: any) {
      console.error('파일럿 로딩 오류:', error)
      alert(`오류: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`"${name}" 파일럿을 삭제하시겠습니까?`)) return

    try {
      const { error } = await supabase
        .from('pilots')
        .delete()
        .eq('id', id)

      if (error) throw error

      alert('삭제되었습니다!')
      loadPilots()
    } catch (error: any) {
      console.error('삭제 오류:', error)
      alert(`삭제 실패: ${error.message}`)
    }
  }

  // 진영 정보 가져오기
  const getFaction = (affiliationId: string) => {
    if (!affiliationId) return null
    return factionsMap[affiliationId] || null
  }

  const getRoleLabel = (role: string) => {
    const roles: any = {
      'protagonist': '주인공',
      'antagonist': '적대자',
      'supporting': '조연',
      'other': '기타',
    }
    return roles[role] || role || '-'
  }

  const totalPages = Math.ceil(totalCount / itemsPerPage)

  const getPageNumbers = () => {
    const pages = []
    const maxVisible = 5
    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      let start = Math.max(1, currentPage - Math.floor(maxVisible / 2))
      let end = Math.min(totalPages, start + maxVisible - 1)
      if (end - start < maxVisible - 1) start = Math.max(1, end - maxVisible + 1)
      for (let i = start; i <= end; i++) pages.push(i)
    }
    return pages
  }

  if (loading && pilots.length === 0) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-900 font-medium">파일럿 목록을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link 
                href="/admin"
                className="text-gray-600 hover:text-gray-900"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </Link>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">👤 파일럿 관리</h1>
                <p className="text-sm text-gray-600 mt-1">총 {totalCount}개</p>
              </div>
            </div>
            <Link
              href="/admin/pilots/new"
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              + 파일럿 추가
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 필터 */}
        <div className="bg-white rounded-xl shadow p-6 mb-6">
          <div className="space-y-4">
            {/* 검색 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">검색</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value)
                  setCurrentPage(1)
                }}
                placeholder="파일럿 이름 검색..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-gray-900  focus:ring-0 text-gray-900 bg-white"
              />
            </div>

            {/* 진영 필터 - 뱃지 형태 */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <label className="block text-sm font-medium text-gray-700">진영 필터</label>
                {selectedFaction && (
                  <button
                    onClick={() => {
                      setSelectedFaction('')
                      setCurrentPage(1)
                    }}
                    className="text-xs text-green-600 hover:text-green-800"
                  >
                    전체 해제
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {factions.length === 0 ? (
                  <p className="text-sm text-gray-500">등록된 진영이 없습니다</p>
                ) : (
                  factions.map((faction) => {
                    const isSelected = selectedFaction === faction.code
                    return (
                      <button
                        key={faction.id}
                        onClick={() => {
                          setSelectedFaction(isSelected ? '' : faction.code)
                          setCurrentPage(1)
                        }}
                        className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                          isSelected
                            ? 'text-white shadow-md'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                        style={isSelected ? { backgroundColor: faction.color || '#16A34A' } : {}}
                      >
                        {faction.name_ko}
                      </button>
                    )
                  })
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 파일럿 테이블 */}
        <div className="bg-white rounded-xl shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    이름
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    코드
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    소속 진영
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    역할
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    탑승 기체
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    작업
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {pilots.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      {searchTerm || selectedFaction ? '검색 결과가 없습니다.' : '등록된 파일럿이 없습니다.'}
                    </td>
                  </tr>
                ) : (
                  pilots.map((pilot) => {
                    const faction = getFaction(pilot.affiliation_default_id)
                    return (
                      <tr key={pilot.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="font-medium text-gray-900">{pilot.name_ko}</div>
                          {pilot.name_en && (
                            <div className="text-sm text-gray-500">{pilot.name_en}</div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {pilot.code ? (
                            <span className="font-mono text-sm text-gray-900 bg-gray-100 px-2 py-1 rounded">
                              {pilot.code}
                            </span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {faction ? (
                            <span 
                              className="px-2 py-1 rounded text-xs font-medium text-white"
                              style={{ backgroundColor: faction.color || '#6B7280' }}
                            >
                              {faction.name_ko}
                            </span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-sm text-gray-700">
                            {getRoleLabel(pilot.role)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 rounded text-xs font-medium bg-orange-100 text-orange-800">
                            {msCounts[pilot.id] || 0}기
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                          <div className="flex items-center justify-end gap-2">
                            <Link
                              href={`/admin/pilots/${pilot.id}/edit`}
                              className="text-green-600 hover:text-green-800 font-medium"
                            >
                              수정
                            </Link>
                            <button
                              onClick={() => handleDelete(pilot.id, pilot.name_ko)}
                              className="text-red-600 hover:text-red-800 font-medium"
                            >
                              삭제
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* 페이지네이션 */}
          {totalPages > 1 && (
            <div className="px-6 py-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700">
                  <span className="font-medium">{totalCount}</span>개 중{' '}
                  <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span>
                  {' '}-{' '}
                  <span className="font-medium">
                    {Math.min(currentPage * itemsPerPage, totalCount)}
                  </span>
                  개 표시
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    이전
                  </button>

                  {getPageNumbers().map((page) => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`px-3 py-1 rounded-lg text-sm font-medium ${
                        currentPage === page
                          ? 'bg-green-600 text-white'
                          : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  ))}

                  <button
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    다음
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
