// src/components/filter-panel.tsx
// 필터 패널 컴포넌트

'use client'

import { useEffect, useState, useRef } from 'react'
import type { Grade, Series, Timeline } from '@/lib/types'

interface LimitedType {
  id: string
  code: string
  name_ko: string
  name_en: string | null
  description: string | null
  badge_color: string | null
  sort_order: number | null
}

interface FilterOptions {
  timelines: Timeline[]
  grades: Grade[]
  series: Series[]
  limitedTypes: LimitedType[]
}

interface FilterPanelProps {
  onFilterChange: (filters: any) => void
}

export function FilterPanel({ onFilterChange }: FilterPanelProps) {
  const [options, setOptions] = useState<FilterOptions>({
    timelines: [],
    grades: [],
    series: [],
    limitedTypes: [],
  })
  const [isOpen, setIsOpen] = useState(false)
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false)
  const sortDropdownRef = useRef<HTMLDivElement>(null)
  
  // 선택된 필터
  const [selectedGrades, setSelectedGrades] = useState<string[]>([])
  const [selectedSeries, setSelectedSeries] = useState<string[]>([])
  const [selectedLimitedTypes, setSelectedLimitedTypes] = useState<string[]>([])
  const [priceMin, setPriceMin] = useState<string>('')
  const [priceMax, setPriceMax] = useState<string>('')
  const [sortBy, setSortBy] = useState<string>('release_date')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')

  // 정렬 옵션
  const sortOptions = [
    { value: 'release_date', label: '출시일' },
    { value: 'name_ko', label: '이름' },
    { value: 'price_krw', label: '가격' },
    { value: 'view_count', label: '조회수' },
  ]

  // 드롭다운 외부 클릭 감지
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (sortDropdownRef.current && !sortDropdownRef.current.contains(event.target as Node)) {
        setIsSortDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // 필터 옵션 로드
  useEffect(() => {
    fetchFilterOptions()
  }, [])

  // 필터 변경 시 부모 컴포넌트에 알림
  useEffect(() => {
    const filters = {
      grade: selectedGrades,
      series: selectedSeries,
      limitedTypes: selectedLimitedTypes,
      priceMin: priceMin ? parseInt(priceMin) : undefined,
      priceMax: priceMax ? parseInt(priceMax) : undefined,
      sortBy,
      sortOrder,
    }
    onFilterChange(filters)
  }, [selectedGrades, selectedSeries, selectedLimitedTypes, priceMin, priceMax, sortBy, sortOrder])

  async function fetchFilterOptions() {
    try {
      const response = await fetch('/api/filters')
      const result = await response.json()
      setOptions(result.data)
    } catch (error) {
      console.error('Failed to fetch filter options:', error)
    }
  }

  const handleGradeToggle = (code: string) => {
    setSelectedGrades(prev =>
      prev.includes(code) ? prev.filter(g => g !== code) : [...prev, code]
    )
  }

  const handleSeriesToggle = (id: string) => {
    setSelectedSeries(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    )
  }

  const handleLimitedTypeToggle = (id: string) => {
    setSelectedLimitedTypes(prev =>
      prev.includes(id) ? prev.filter(lt => lt !== id) : [...prev, id]
    )
  }

  const handleReset = () => {
    setSelectedGrades([])
    setSelectedSeries([])
    setSelectedLimitedTypes([])
    setPriceMin('')
    setPriceMax('')
    setSortBy('release_date')
    setSortOrder('desc')
  }

  const activeFilterCount = 
    selectedGrades.length + 
    selectedSeries.length + 
    selectedLimitedTypes.length +
    (priceMin ? 1 : 0) + 
    (priceMax ? 1 : 0)

  return (
    <div>
      {/* 필터 버튼 (모바일) */}
      <div className="lg:hidden mb-4">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="btn-secondary w-full flex items-center justify-between"
        >
          <span>필터 {activeFilterCount > 0 && `(${activeFilterCount})`}</span>
          <span>{isOpen ? '▲' : '▼'}</span>
        </button>
      </div>

      {/* 필터 패널 */}
      <div className={`space-y-6 ${isOpen ? 'block' : 'hidden lg:block'}`}>
        {/* 정렬 */}
        <div className="card-threads">
          <h3 className="font-bold mb-3">정렬</h3>
          <div className="space-y-2">
            {/* 커스텀 드롭다운 */}
            <div className="relative" ref={sortDropdownRef}>
              <button
                type="button"
                onClick={() => setIsSortDropdownOpen(!isSortDropdownOpen)}
                className="w-full flex items-center justify-between px-4 py-3 bg-secondary border border-border rounded-xl text-foreground hover:bg-accent transition-colors"
              >
                <span>{sortOptions.find(opt => opt.value === sortBy)?.label}</span>
                <svg 
                  className={`w-4 h-4 transition-transform ${isSortDropdownOpen ? 'rotate-180' : ''}`} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              {/* 드롭다운 메뉴 */}
              {isSortDropdownOpen && (
                <div className="absolute z-50 w-full mt-1 py-1 bg-card border border-border rounded-xl shadow-lg overflow-hidden">
                  {sortOptions.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => {
                        setSortBy(option.value)
                        setIsSortDropdownOpen(false)
                      }}
                      className={`w-full px-4 py-2.5 text-left transition-colors ${
                        sortBy === option.value
                          ? 'bg-primary text-black font-medium'
                          : 'text-foreground hover:bg-secondary'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setSortOrder('desc')}
                className={`flex-1 py-2 rounded-lg transition-colors ${
                  sortOrder === 'desc'
                    ? 'bg-primary text-black font-bold'
                    : 'bg-secondary text-muted-foreground'
                }`}
              >
                내림차순
              </button>
              <button
                onClick={() => setSortOrder('asc')}
                className={`flex-1 py-2 rounded-lg transition-colors ${
                  sortOrder === 'asc'
                    ? 'bg-primary text-black font-bold'
                    : 'bg-secondary text-muted-foreground'
                }`}
              >
                오름차순
              </button>
            </div>
          </div>
        </div>

        {/* 등급 */}
        <div className="card-threads">
          <h3 className="font-bold mb-3">등급</h3>
          <div className="flex flex-wrap gap-2">
            {options.grades.map((grade) => (
              <button
                key={grade.id}
                onClick={() => handleGradeToggle(grade.code)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  selectedGrades.includes(grade.code)
                    ? 'bg-primary text-black'
                    : 'bg-secondary text-foreground hover:bg-accent'
                }`}
              >
                {grade.code}
              </button>
            ))}
          </div>
        </div>

        {/* 시리즈 - 년도순 정렬 */}
        <div className="card-threads">
          <h3 className="font-bold mb-3">시리즈</h3>
          <div className="flex flex-col gap-1.5">
            {[...options.series]
              .sort((a, b) => (a.year_start || 9999) - (b.year_start || 9999))
              .map((series) => (
              <button
                key={series.id}
                onClick={() => handleSeriesToggle(series.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors text-left ${
                  selectedSeries.includes(series.id)
                    ? 'bg-primary text-black'
                    : 'bg-secondary text-foreground hover:bg-accent'
                }`}
              >
                {series.name_ko}
              </button>
            ))}
          </div>
        </div>

        {/* 가격 범위 */}
        <div className="card-threads">
          <h3 className="font-bold mb-3">가격 범위</h3>
          <div className="space-y-2">
            <input
              type="number"
              placeholder="최소 가격"
              value={priceMin}
              onChange={(e) => setPriceMin(e.target.value)}
              className="input-threads w-full"
            />
            <input
              type="number"
              placeholder="최대 가격"
              value={priceMax}
              onChange={(e) => setPriceMax(e.target.value)}
              className="input-threads w-full"
            />
          </div>
        </div>

        {/* 한정판 - 동적 로드 */}
        {options.limitedTypes.length > 0 && (
          <div className="card-threads">
            <h3 className="font-bold mb-3">한정판</h3>
            <div className="flex flex-col gap-1.5">
              {options.limitedTypes.map((limitedType) => (
                <button
                  key={limitedType.id}
                  onClick={() => handleLimitedTypeToggle(limitedType.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors text-left flex items-center gap-2 ${
                    selectedLimitedTypes.includes(limitedType.id)
                      ? 'text-white'
                      : 'bg-secondary text-foreground hover:bg-accent'
                  }`}
                  style={selectedLimitedTypes.includes(limitedType.id) 
                    ? { backgroundColor: limitedType.badge_color || '#DC2626' } 
                    : {}
                  }
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: limitedType.badge_color || '#DC2626' }}
                  />
                  {limitedType.name_ko}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 초기화 버튼 */}
        {activeFilterCount > 0 && (
          <button
            onClick={handleReset}
            className="btn-secondary w-full"
          >
            필터 초기화 ({activeFilterCount})
          </button>
        )}
      </div>
    </div>
  )
}
